#ifndef MENU_H_
#define MENU_H_
#include<stdio.h>
#include<stdlib.h>
#include"utn.h"

int menu_Main(int*);
int menu_Variables(int*);


#endif /* MENU_H_ */
